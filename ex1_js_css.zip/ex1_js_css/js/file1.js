var fd2 = require("./file2.js");
var css = require("!style!css!../styles/app.css");

console.log("output from JS - #1.");
console.log(fd2) ;
