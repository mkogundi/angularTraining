document.write("another output from JS.");
console.log("another output from JS - #2.");
