import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import {routing} from "./app.routing";
import {HomeComponent} from "../app52_jbtron_router/components/pages/home.component";
import {AboutComponent} from "../app52_jbtron_router/components/pages/about.component";

@NgModule({
  imports: [ BrowserModule, routing ],
  declarations: [ AppComponent, HomeComponent, AboutComponent ],
  providers:[],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
