


import { Component } from '@angular/core';

import {NavbarComponent} from './components/navbar/navbar.component';
import {JumbotronComponent} from './components/jumbotron/jumbotron.component';


@Component({
  selector: 'my-app',
  directives: [NavbarComponent, JumbotronComponent ],
  template: `
        <navbar></navbar>
        <jumbotron></jumbotron>
        
        <div class="container">
            <nav>    </nav>
            
            <router-outlet></router-outlet>
        </div>
  `

})


export class AppComponent {}

